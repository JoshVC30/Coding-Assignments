/*
 * Class: CMSC140 CRN 30552
 * Instructor: Professor Justh
 * Project4
 * Description: This is a program meant to calculate the average number of 
   days a company's employees are absent during the year and outputs a 
   report on a file named "employeeAbsences.txt".  
 * Due Date: April 19, 2019
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Joshua Vazquez Correa
*/

#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>

using namespace std;

int numOfEmployees();															//prototype for the number of employees
int totDaysAbsent(ofstream&, int);												//prototype for the total days absent
double averageAbsent(int&, int&);												//prototype for the average number of days absent

const string PROG_NAME = "Joshua Vazquez Correa";								//store programmer�s name as a constant

int main()
{
	int employees;																//store number of employees
	int absent;																	//store number of absences
	double average;																//store average days absent as double
	int ttl_absences;															//store the overall total absences
	
	ofstream outfile;															//initialize the output file
	
	//display title
	cout << "Calculate the average number of days a company's employees are absent.\n" << endl;

	//open file named employeeAbsences
	outfile.open("employeeAbsences.txt");
	//write the file tittle into the file
	outfile << "EMPLOYEE ABSENCE REPORT" << endl;
	outfile << "employee id	days absent" << endl;

	//call the numOfEmployees function
	employees = numOfEmployees();
	//call the totDaysAbsent function
	absent = totDaysAbsent(outfile, employees);
	//call the averageAbsent function
	average = averageAbsent(absent, employees);
	
	//write the average number of days absent with 2 decimal points in file
	outfile << "The average number of days absent is " << setprecision(2) << fixed << showpoint << (float)average << " days.";

	//display programmer name in output and file
	cout << "Programmer: " << PROG_NAME << endl;
	outfile << "\nProgrammer: " << PROG_NAME << endl;

	system("pause");
	
}

//function for the number of employees
int numOfEmployees() 
{
	int employees;

	//prompt the number of employees in the company
	cout << "Please enter the number of employees in the company: ";
	cin >> employees;

	//validate answer, number must not be less than zero
	while (employees < 1)
	{
		cout << "The number of employees cannot be less than one." << endl;
		cout << "Please re-enter the number of employees in the company: ";
		cin >> employees;
	}


	return employees;
}

//function for total days absent per employees
int totDaysAbsent(ofstream& outfile, int employees)
{
	
	int id;
	int absent = 0;
	int ttl_absences = 0;

	//for loop that repeats the prompts for every employee
	for (int i = 1; i <= employees; i++)
	{
		//prompt employee number
		cout << "Enter the employee number (ID): ";
		cin >> id;

		//prompt the days the employee was absent
		cout << "Enter the number of days the employee missed during the past year: ";
		cin >> absent;

		//validate answer, number must be positive
		while (absent < 0)
		{
			cout << "The number of days must not be negative." << endl;
			cout << "Please re-enter the number of days absent: ";
			cin >> absent;
		}

		//write into file all employee IDs and absences  
		outfile << "   " << id << "		  " << absent << endl;
		
		//calculate total absences
		ttl_absences += absent;
	}

	
	//write into file the number of employees and the total absences
	outfile << "\nThe " << employees << " employees were absent a total of " << ttl_absences << " days." << endl;

	return ttl_absences;
}

//functio for the average absence
double averageAbsent(int& ttl_absences, int& employees)
{
	double average;
	
	//calculate average
	average = (double)ttl_absences / employees;

	return average;
}

