/**
 * @author Joshua Vazquez Correa
 */

import java.util.ArrayList;

public class Town implements Comparable<Town>{

	protected String name;
	protected ArrayList<Town> adjacentTowns;
	
	
	public Town(String name) {
		this.name = name;
		adjacentTowns = new ArrayList<Town>();
	}

	public Town(Town templateTown) {
		this.name = templateTown.name;

		this.adjacentTowns = new ArrayList<Town>();

		for (Town t : templateTown.adjacentTowns) {
			this.adjacentTowns.add(t);
		}
	}
	public String getName() {
		return name;
		
	}
	
	public int compareTo(Town o) {
		return name.compareTo(o.name);
		
	}
	
	public String toString(){
		return name;
		
	}
	
	public int hashCode() {
		return name.hashCode();
		
	}
	
	public boolean equals(Object obj) {
		if (obj == this)
			return true;

		if (!(obj instanceof Town))
			return false;

		Town t = (Town) obj;

		return this.name.equals(t.name);
		
	}
}
