/**
 * @author Joshua Vazquez Correa
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Graph implements GraphInterface<Town, Road> {
	private Set<Town> towns = new HashSet<Town>();
	private Set<Road> roads = new HashSet<Road>();
	
	private Map<Town, Town> map = new HashMap<Town, Town>();
	private Map<Town, Integer> weight = new HashMap<Town, Integer>();


	/**
	 * constructor
	 */
	public Graph() {	
		
	}

	 /**
     * Returns an edge connecting source vertex to target vertex if such
     * vertices and such edge exist in this graph. Otherwise returns
     * null. If any of the specified vertices is null
     * returns null
     * 
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return an edge connecting source vertex to target vertex.
     */
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		
		if (sourceVertex == null || destinationVertex == null)
			return null;

		if (!containsVertex(sourceVertex) || !containsVertex(destinationVertex))
			return null;

		for (Road road : edgesOf(sourceVertex)) {
			if (road.getDestination().equals(destinationVertex))
				return road;
		}

		return null;
	}

	/**
     * Creates a new edge in this graph, going from the source vertex to the
     * target vertex, and returns the created edge. 
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description for edge
     *
     * @return The newly created edge if added to the graph, otherwise null.
     *
     * @throws IllegalArgumentException if source or target vertices are not
     * found in the graph.
     * @throws NullPointerException if any of the specified vertices is null.
     */
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		 
		Road newEdge;

		if (sourceVertex == null || destinationVertex == null)
			throw new NullPointerException();

		if (!containsVertex(sourceVertex) || !containsVertex(destinationVertex))
			throw new IllegalArgumentException();

		newEdge = new Road(sourceVertex, destinationVertex, weight, description);


		roads.add(newEdge);

		return newEdge;
	}

    /**
     * Adds the specified vertex to this graph if not already present. 
     *
     * @param v vertex to be added to this graph.
     *
     * @return true if this graph did not already contain the specified
     * vertex.
     *
     * @throws NullPointerException if the specified vertex is null.
     */
	public boolean addVertex(Town v) {
		 
		if (v == null) {
			throw new NullPointerException();
		}

		if (containsVertex(v)) {
			return false;
		}
		towns.add(v);

		return true;
	}
	
	 /**
     * Returns true if and only if this graph contains an edge going
     * from the source vertex to the target vertex. 
     * 
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return true if this graph contains the specified edge.
     */
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		boolean containsE = false;
		for(Road road: roads) {
			if (road.contains(sourceVertex) && road.contains(destinationVertex)) {
				containsE = true;
				return containsE;
			}
		}
		
		return containsE;		
	}
	
	/**
     * Returns true if this graph contains the specified vertex. 
     * @param v vertex whose presence in this graph is to be tested.
     *
     * @return true if this graph contains the specified vertex.
     */
	public boolean containsVertex(Town v) {
		 
		if (v == null) {
			return false;
		} else {
			return towns.contains(v);
		}
	}
	
	/**
     * Returns a set of the edges contained in this graph. 
     *
     * @return a set of the edges contained in this graph.
     */
	public Set<Road> edgeSet() {
		 
		return roads;
	}

	 /**
     * Returns a set of all edges touching the specified vertex (also
     * referred to as adjacent vertices). If no edges are
     * touching the specified vertex returns an empty set.
     *
     * @param vertex the vertex for which a set of touching edges is to be
     * returned.
     *
     * @return a set of all edges touching the specified vertex.
     *
     * @throws IllegalArgumentException if vertex is not found in the graph.
     * @throws NullPointerException if vertex is null.
     */
	public Set<Road> edgesOf(Town vertex) {
		
		Set<Road> adjacent = new HashSet<Road>();
		if (vertex == null)
			throw new NullPointerException();

		if (!containsVertex(vertex))
			throw new IllegalArgumentException();

		

		for (Road road : roads) {
			if (road.getSource().equals(vertex))
				adjacent.add(road);

		}

		return adjacent;
		}

	
	/**
     * Removes an edge going from source vertex to target vertex, if such
     * vertices and such edge exist in this graph. 
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description of the edge
     *
     * @return The removed edge, or null if no edge removed.
     */
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {

		if (sourceVertex == null || destinationVertex == null)
			return null;

		Road removedRoad = new Road(sourceVertex, destinationVertex, weight, description);

			for (Road road : roads) {
				if (road.contains(sourceVertex) && road.contains(destinationVertex) && (weight > -1) && description != null)
			
					removedRoad = road;
			}
			if (roads.remove(removedRoad)) {
			return removedRoad;

		}

		return null;
	}

	 /**
     * Removes the specified vertex from this graph including all its touching
     * edges if present. 
     * @param v vertex to be removed from this graph, if present.
     * @return true if the graph contained the specified vertex;
     * false otherwise.
     */
	public boolean removeVertex(Town v) {
		 
		if (v == null) {
			return false;
		} else {
			return towns.remove(v);
		}
		

	}

	 /**
     * Returns a set of the vertices contained in this graph. 
     * @return a set view of the vertices contained in this graph.
     */
	public Set<Town> vertexSet() {
		return towns; 

	}

	

	/**
     * Find the shortest path from the sourceVertex to the destinationVertex
     * call the dijkstraShortestPath with the sourceVertex
     * @param sourceVertex starting vertex
     * @param destinationVertex ending vertex
     * @return An arraylist of Strings that describe the path from sourceVertex to destinationVertex
     * 
     */   
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		ArrayList<String> shortest = new ArrayList<String>();

		boolean correct = false;

		for(Road road: roads) {
			if(road.contains(destinationVertex))
				correct = true;
		}
		if(!correct) {
			return shortest;
		}
		dijkstraShortestPath(sourceVertex);

		Town temp = destinationVertex;

		while(!temp.equals(sourceVertex)) {
			for(Road road: roads) {
				if(road.contains(temp) && road.contains(map.get(temp)))
					shortest.add(0, map.get(temp).getName() + " via " + road.getName() + " to " + temp.getName() + " " + road.getWeight() + " mi");
			}
			temp = map.get(temp);
		}
		return shortest;
	}

	
	  /**
     * Dijkstra's Shortest Path Method.  Internal structures are built which
     * hold the ability to retrieve the path, shortest distance from the
     * sourceVertex to all the other vertices in the graph, etc.
     * @param sourceVertex the vertex to find shortest path from
     * 
     */
	public void dijkstraShortestPath(Town sourceVertex) {
		HashSet<Town> temp = new HashSet<>();
		
		for(Town town: towns) {
			temp.add(town);
		}

		for(Town town: towns) {
			weight.put(town, Integer.MAX_VALUE);
		}
		weight.put(sourceVertex, 0);

		while(!temp.isEmpty()) {
			for(Road road: roads) {
				if(road.contains(sourceVertex)) {
					if(!road.getDestination().equals(sourceVertex) && temp.contains(road.getDestination())) {
						if(weight.get(sourceVertex) + road.getWeight() < weight.get(road.getDestination())) {
							map.put(road.getDestination(), sourceVertex);
							weight.put(road.getDestination(), road.getWeight() + weight.get(sourceVertex));
						}
					}
					else if(!road.getSource().equals(sourceVertex) && temp.contains(road.getSource()))
						if(weight.get(sourceVertex) + road.getWeight() < weight.get(road.getSource())) {
							map.put(road.getSource(), sourceVertex);
							weight.put(road.getSource(), road.getWeight() + weight.get(sourceVertex));
						}
				}
			}
			temp.remove(sourceVertex);

			int min = 100;
			for(Town town: weight.keySet()) {	
				if(min >  weight.get(town) && temp.contains(town)) {
					min = weight.get(town);
					sourceVertex = town;
				}
			}
		}
	}
}
