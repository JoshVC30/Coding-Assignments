/**
 * @author Joshua Vazquez Correa
 */

public class Road implements Comparable<Road>{

	private Town source, destination;
	private int degrees;
	private String name;
	
	public Road(Town source, Town destination, int degrees, String name) {
		this.source = new Town(source);
		this.destination = new Town(destination);

		this.name = name;
		this.degrees = degrees;
	}
	
	
	public Road(Town source, Town destination, String name) {
		this.source = new Town(source);
		this.destination = new Town(destination);

		this.name = name;
		this.degrees = 1;
	}
	
	public boolean contains(Town town) {
		return this.source.equals(town) || this.destination.equals(town);
		
	}
	
	public String toString(){
		return source.getName() + " via " + name + " to " + destination.getName() + " " + degrees + " mi";
		
	}
	
	public String getName(){
		return name;
		
	}
	
	public Town getDestination() {
		return destination;
		
	}
	
	public Town getSource() {
		return source;
		
	}
	
	public int compareTo(Road o) {
		return this.name.compareTo(o.name);
		
	}
	
	public int getWeight() {
		return degrees;
		
	}
	
	public boolean equals(Object r) {
		if (r == this)
			return true;

		if (!(r instanceof Road))
			return false;

		Road road = (Road) r;

		return (this.source.equals(road.source) && this.destination.equals(road.destination))
				|| (this.source.equals(road.destination) && this.destination.equals(road.source));		
	}
	
}
