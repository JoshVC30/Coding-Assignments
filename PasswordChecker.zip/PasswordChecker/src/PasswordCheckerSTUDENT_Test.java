import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.function.Executable;


/**
 * This is your test file.  Complete the following test cases to test your project where they make sense.
 * Include additional test cases if you like.  
 *
 * STUDENT tests for the methods of PasswordChecker
 * @author Joshua Vazquez Correa
 *
 */
public class PasswordCheckerSTUDENT_Test {
	
	ArrayList<String> passwordsArray;
	String password = "Josh";
	String allCaps = "JOSHUA";
	String withDigit = "J0shua";

	@Before
	public void setUp() throws Exception {
		String[] p = {"JJ00SSHH", "ImJ0shu4",withDigit, allCaps};
		passwordsArray = new ArrayList<String>();
		passwordsArray.addAll(Arrays.asList(p));
	}

	@After
	public void tearDown() throws Exception {
		passwordsArray = null;
	}

	/**
	 * Test if the password is less than 6 characters long.
	 * This test should throw a LengthException for second case.
	 */
	@Test
	public void testIsValidPasswordTooShort()
	{
		Throwable exception = Assertions.assertThrows(LengthException.class, new Executable() {
			@Override
			public void execute() throws Throwable {
				PasswordCheckerUtility.isValidLength(password);
			}			
		});
		assertEquals("The password must be at least 6 characters long", exception.getMessage());
	}
	
	/**
	 * Test if the password has at least one uppercase alpha character
	 * This test should throw a NoUpperAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoUpperAlpha()
	{
		try {
			assertTrue(PasswordCheckerUtility.hasUpperAlpha("Vazquez"));
		} catch (NoUpperAlphaException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test if the password has at least one lowercase alpha character
	 * This test should throw a NoLowerAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoLowerAlpha()
	{
		try {
			assertTrue(PasswordCheckerUtility.hasLowerAlpha("Joshua"));
		} catch (NoLowerAlphaException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test if the password is weak
	 * This test should throw a WeakPasswordException for second case
	 */
	@Test
	public void testIsWeakPassword()
	{
	        try {
	            assertTrue(PasswordCheckerUtility.isWeakPassword("Joshua1/"));
	        } catch(WeakPasswordException e) {
	        	e.printStackTrace();
	    }
	}
	
	/**
	 * Test if the password has at least one digit
	 * One test should throw a NoDigitException
	 */
	@Test
	public void testIsValidPasswordNoDigit()
	{
		try {
			assertTrue(PasswordCheckerUtility.hasDigit("Joshua1"));
		} catch (NoDigitException e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * Test the invalidPasswords method
	 * Check the results of the ArrayList of Strings returned by the validPasswords method
	 */
	@Test
	public void testInvalidPasswords() {
		ArrayList<String> results;
		results = PasswordCheckerUtility.getInvalidPasswords(passwordsArray);
		assertEquals(results.size(), 4);
		assertEquals(results.get(0), "JJ00SSHH -> The password must contain at least one lowercase alphabetic character");
		assertEquals(results.get(1), "ImJ0shu4 -> The password must contain at least one special character");
		assertEquals(results.get(3), "JOSHUA -> The password must contain at least one lowercase alphabetic character");
	}

	}
	
