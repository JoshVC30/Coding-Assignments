/**
 * Thrown if a password is less than six characters long.
 * @author Joshua Vazquez Correa
 */
public class WeakPasswordException extends RuntimeException {
	/**
	 * Constructor.
	 */
	public WeakPasswordException() {
		this("The password is OK but weak - it contains fewer than 10 characters");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public WeakPasswordException(String message) {
		super(message);
	}
}
