/**
 * Thrown if a password is less than six characters long.
 * @author Joshua Vazquez Correa
 */
public class UnmatchedException extends RuntimeException {
	/**
	 * Constructor.
	 */
	public UnmatchedException() {
		this("The passwords do not match");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public UnmatchedException(String message) {
		super(message);
	}
}
