/**
 * Thrown if a password has no lowercase alphabetic character.
 * @author Joshua Vazquez Correa
 */
public class NoLowerAlphaException extends RuntimeException {
	/**
	 * Constructor.
	 */
	public NoLowerAlphaException() {
		this("The password must contain at least one lowercase alphabetic character");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public NoLowerAlphaException(String message) {
		super(message);
	}
}
