/**
 * PasswordCheckerUtility class checks whether the passwords are valid or not.
 * @author Joshua Vazquez Correa
 */

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordCheckerUtility {

	/**
	 * Compare equality of two passwords
	 * @param password
	 * @param passwordConfirm
	 * @throws UnmatchedException
	 */
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException {
		password.equals(passwordConfirm);
		if(!(password.equals(passwordConfirm)))
			throw new UnmatchedException();
	}
	
	/**
	 * Compare equality of two passwords and returns with a true or false
	 * @param password
	 * @param passwordConfirm
	 * @return true if both are the same (case sensitive)
	 */
	public static boolean comparePasswordsWithReturn(String password, String passwordConfirm) {
		if(password.equals(passwordConfirm)) {
			return true;
		}
		else
			return false;
	}
	
	/**
	 * Reads a file of passwords and the passwords that failed the check will be added to an 
	 * invalidPasswords array list.
	 * @param passwords
	 * @return invalidPasswords - an array list of invalid passwords
	 */
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
		ArrayList<String> invalidPasswords = new ArrayList<String>();
		
		for(String password : passwords) {
			try {
				isValidPassword(password);
			}
			catch(Exception ex) {
				invalidPasswords.add(password + " -> " + ex.getMessage());
			}
		}
		return invalidPasswords;
	}
	
	/**
	 * Checks if the password contains 6 to 9 characters. If so, it is a weak password.
	 * @param password
	 * @return true if password contains 6 to 9 characters, false if not
	 */
	public static boolean hasBetweenSixAndNineChars(String password) {
	
		if(password.length() >= 6 && password.length()<=9) {
			return true;
		}
		else
			return false;
	}
	
	
	/**
	 * Checks if the password has number digits in it. If not, it throws NoDigitException.
	 * @param password
	 * @return true if the password has at least one digits
	 * @throws NoDigitException
	 */
	public static boolean hasDigit(String password) throws NoDigitException {
		boolean digit = false;

		for (int i = 0; i < password.length(); i++){
	       
	        if (Character.isDigit(password.charAt(i))) 
	        {
	            digit = true;
	        }
		}
		if(digit == false) {
			throw new NoLowerAlphaException();
		}
		else {
			return digit;
		}
	}
	
	
	/**
	 * Checks if the password has at least one lowercase alpha characters. If not, throws NoLowerAlphaException
	 * @param password
	 * @return true if the password has at least one lowercase alpha character
	 * @throws NoLowerAlphaException
	 */
	public static boolean hasLowerAlpha(String password) throws NoLowerAlphaException{
	
	boolean lowerAlpha = false;

		for (int i = 0; i < password.length(); i++){
	       
	        if (Character.isLowerCase(password.charAt(i))) 
	        {
	            lowerAlpha = true;
	        }
		}
		if(lowerAlpha == false) {
			throw new NoLowerAlphaException();
		}
		else {
			return lowerAlpha;
		}
	}
	
	/**
	 * Checks if the password contains more than 2 of the same character in sequence. 
	 * If it has more than 2 characters in a row throws InvalidSequenceException.
	 * @param password
	 * @return false if it doesn't have more than 2 of the same character in a row
	 * @throws InvalidSequenceException
	 */
	public static boolean hasSameCharInSequence(String password) throws InvalidSequenceException {
		boolean sameChar = false;
		for(int i = 0; i < password.length()-2; i++) {
			if(password.charAt(i) == password.charAt(i+1) && password.charAt(i) == password.charAt(i+2)) {
				sameChar = true;				
			}
		}
		if(sameChar == true) {
			throw new InvalidSequenceException();
		}
		return sameChar;
	}
	
	
	/**
	 * Checks if the password has special characters. The password must contain at least one special character.
	 * @param password
	 * @return true if it meets the special character requirement
	 * @throws NoSpecialCharacterException
	 */
	public static boolean hasSpecialChar(String password) throws NoSpecialCharacterException 
	{
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(password); 
		if(matcher.matches()) {
			throw new NoSpecialCharacterException();
		}
		return !matcher.matches();	
		
		
	}
	
	/**
	 * Checks if the password has at least one uppercase alpha characters. If not, throws NoUpperAlphaException
	 * @param password
	 * @return true if the password has at least one uppercase alpha character
	 * @throws NoUpperAlphaException
	 */
	public static boolean hasUpperAlpha(String password) throws NoUpperAlphaException{
		boolean upperAlpha = false;

		for (int i = 0; i < password.length(); i++){
	       
	        if (Character.isUpperCase(password.charAt(i))) 
	        {
	            upperAlpha = true;
	        }
		}
		if(upperAlpha == false) {
			throw new NoUpperAlphaException();
		}
		else {
			return upperAlpha;
		}
	}
	
	
	/**
	 * Checks if the password is at least 6 characters long. If not, throws LengthException.
	 * @param password
	 * @return true if it has 6 or more characters
	 * @throws LengthException
	 */
	public static boolean isValidLength(String password) throws LengthException {
		if(password.length() >= 6) {
			return true;
		}
		else
			throw new LengthException();
	}
	
	/**
	 * Checks if the password is valid or not
	 * @param password
	 * @return true if it's a valid password (follows all rules from above), returns false if it's an invalid password
	 * @throws LengthException
	 * @throws NoUpperAlphaException
	 * @throws NoLowerAlphaException
	 * @throws NoDigitException
	 * @throws NoSpecialCharacterException
	 * @throws InvalidSequenceException
	 */
	public static boolean isValidPassword(String password) throws LengthException, NoUpperAlphaException, NoLowerAlphaException, 
																  NoDigitException, NoSpecialCharacterException, InvalidSequenceException
	{
		if(isValidLength(password) && hasUpperAlpha(password) && hasLowerAlpha(password) && hasDigit(password) 
		   && hasSpecialChar(password) && !hasSameCharInSequence(password))
		{
			return true;
		}else {
			if(!isValidLength(password))
				throw new LengthException();
			if(!hasUpperAlpha(password))
				throw new NoUpperAlphaException();	
			if(!hasLowerAlpha(password))
				throw new NoLowerAlphaException();
			if(!hasDigit(password))
				throw new NoDigitException();
			if(!hasSpecialChar(password))
				throw new NoSpecialCharacterException();
			if(hasSameCharInSequence(password))
				throw new InvalidSequenceException();			
			return false;
			}		
	}
	
	/**
	 * Checks if password is valid but between 6 - 9 characters. If it is throw WeakPasswordException
	 * @param password
	 * @return true if length of password is between 6 and 9
	 * @throws WeakPasswordException
	 */
		public static boolean isWeakPassword(String password) throws WeakPasswordException{
		if(password.length() >= 6 && password.length()<=9) {
			return true;
		}
		else
			throw new WeakPasswordException();
	}
}
