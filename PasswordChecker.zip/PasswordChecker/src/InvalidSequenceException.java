/**
 * Thrown if a password has more than 2 of the same character in sequence.
 * @author Joshua Vazquez Correa
 */
public class InvalidSequenceException extends RuntimeException {
	/**
	 * Constructor.
	 */
	public InvalidSequenceException() {
		this("The password cannot contain more than two of the same character in sequence");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public InvalidSequenceException(String message) {
		super(message);
	}
}

