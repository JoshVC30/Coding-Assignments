/**
 * Thrown if a password has no numeric character.
 * @author Joshua Vazquez Correa
 */
public class NoDigitException extends RuntimeException {
	/**
	 * Constructor.
	 */
	public NoDigitException() {
		this("The password must contain at least one digit");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public NoDigitException(String message) {
		super(message);
	}
}

