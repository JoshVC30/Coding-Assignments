/**
 * Thrown if a password has no special character.
 * @author Joshua Vazquez Correa
 */
public class NoSpecialCharacterException extends RuntimeException {
	/**
	 * Constructor.
	 */
	public NoSpecialCharacterException() {
		this("The password must contain at least one special character");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public NoSpecialCharacterException(String message) {
		super(message);
	}
}

