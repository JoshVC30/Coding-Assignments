/**
 * 
 * @author Joshua Vazquez Correa
 *
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {

	CourseDBStructure struct = new CourseDBStructure(20);
	
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		
		CourseDBElement element = new CourseDBElement(id, crn,credits,roomNum,instructor);
		struct.add(element);

	}
	
	
	@Override
	public CourseDBElement get(int crn) {
		
		try
        {
            return struct.get(crn);
        }
        catch (IOException e)
        {
           e.printStackTrace();
        }
        return null;
	}

	
	 
	
	
	@Override
	public void readFile(File input) throws FileNotFoundException {
		
		PrintWriter invalids = new PrintWriter("invalid_entries.txt");
		
		if (input == null) {
			throw new FileNotFoundException();
		}
		Scanner sc = new Scanner(input);
	
		while(sc.hasNextLine()) {
			String line = sc.nextLine(); 
			
			try{
				 
				 Scanner lineSc = new Scanner(line);
				 String id, roomNum, instructor;				 
			 
				int crn, credits;
				 				 
				if(lineSc.hasNextInt() == false) {
					id = lineSc.next();
					
					if(id.charAt(0) == '#') {
						
						continue;
					}
		/**
		 * I tried to make a condition where the course id's can only start with "CSMC" and it worked, 
		 * but for some reason it messed up the showDB in the  output and I couldn't figure out why. 		
		 */
					
//					if(!id.startsWith("CMSC")) {
//						
//						throw new Exception("invalid entry BAD (COURSE) ID");
//					}
					
				}else {
					
					throw new Exception("invalid entry MISSING (COURSE) ID");
				}
				
				if(lineSc.hasNextInt()) {
					crn = lineSc.nextInt();
					if(crn < 0) {
						
						throw new Exception("invalid entry BAD CRN");
					}
				}else {
					
					throw new Exception("invalid entry MISSING CRN");
				}
				
				if(lineSc.hasNextInt()) {
					credits = lineSc.nextInt();
					if(credits <= 0 || credits > 4) {
						
						throw new Exception("invalid entry BAD CREDIT HOURS");
					}
				}else {
					//line.nextLine();
					throw new Exception("invalid entry");
				}
				
				if(lineSc.hasNext()) {
					roomNum = lineSc.next();						
				}else {
					
					throw new Exception("invalid entry");
				}
				
				if(lineSc.hasNext()) {
					instructor = lineSc.nextLine();	
					instructor = instructor.trim();
				}else {
					
					throw new Exception("invalid entry");
				}
				
				struct.add(new CourseDBElement(id, crn, credits, roomNum, instructor));
				lineSc.close();
			}
			catch (Exception e) {
				
				invalids.println(line);
						
			}
		}
		
		sc.close();
		invalids.close();
	
	}
	
	
	
	
	@Override
	public ArrayList<String> showAll() {
		
		ArrayList<String> show = new ArrayList<>();
        for(int i=0; i <struct.getTableSize(); i++)
        {
            if(struct.hashTable[i]!=null)
            {
                for(CourseDBElement elmnt: struct.hashTable[i])
                {
                   show.add(elmnt.toString());
                }
            }
        }

        return show;
	}	
}
