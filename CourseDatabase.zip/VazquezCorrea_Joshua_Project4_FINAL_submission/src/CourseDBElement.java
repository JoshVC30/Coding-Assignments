/**
 * 
 * @author Joshua Vazquez Correa
 *
 */

public class CourseDBElement implements Comparable<CourseDBElement>{
	
	protected String id;
	protected int crn;
	protected int credits;
	protected String roomNum;
	protected String instructor;

    /**
     * Constructors for the course ID, crn, credit hours, room number, and instructor
     * @param id
     * @param crn
     * @param credits
     * @param roomNum
     * @param instructor
     */
	public CourseDBElement(String id, int crn, int credits, String roomNum, String instructor) {
		
		this.id = id;
		this.crn = crn;
		this.credits = credits;
		this.roomNum = roomNum;
		this.instructor = instructor;
	}

	
	public CourseDBElement() {
		
	}

	/**
	 * String method that gets the course ID
	 * @return id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Void method that sets the course ID
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Int method that gets the crn.
	 * @return crn
	 */
	public int getCRN() {
		return crn;
	}
	
	/**
	 * Void method that sets the crn
	 * @param crn
	 */
	public void setCRN(int crn) {
		this.crn = crn;
	}

	/**
	 * Int method that gets the credit hours.
	 * @return credits
	 */
	public int getCredits() {
		return credits;
	}
	
	/**
	 * Void method that sets the credit hours.
	 * @param credits
	 */
	public void setCredits(int credits) {
		this.credits = credits;
	}
	
	/**
	 * String method that gets the room number
	 * @return roomNum
	 */
	public String getRoomNum() {
		return roomNum;
	}
	
	/**
	 * Void method that sets the room number
	 * @param roomNum
	 */
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}

	/**
	 * String method that gets the instructor's name
	 * @return instructor
	 */
	public String getInstructor() {
		return instructor;
	}
	
	/**
	 * Void method that sets the instructor's name.
	 * @param instructor
	 */
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	
	/**
	 * CompareTo method
	 */
	@Override
	public int compareTo(CourseDBElement cde) {

		if (this.crn > cde.crn) {
            return 1;
		}
		
		else if(this.crn < cde.crn) {
           return -1;
        }
		
        else 
            return 0;
	}
	
	/**
	 * ToString method
	 */
	@Override
    public String toString()
    {
        String toStr = "\nCourse:" + id + " CRN:" + crn + " Credits:" + credits + " Instructor:" + instructor + " Room:" + roomNum;
		return toStr;
    }

	/**
	 * hashCode method
	 */
	 @Override
	    public int hashCode()
	    {
	       return Integer.toString(crn).hashCode();
	    }
}
