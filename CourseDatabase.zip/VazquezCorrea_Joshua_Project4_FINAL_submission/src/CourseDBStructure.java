/**
 * 
 * @author Joshua Vazquez Correa
 *
 */

import java.io.IOException;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {

	public LinkedList<CourseDBElement>[] hashTable;

	private int hashSize = 0;
	
	
	public CourseDBStructure(String test, int courses) {
		hashSize = courses;
	    hashTable = new LinkedList[hashSize];
	    for (int i = 0; i < courses; i++) {
	    	hashTable[i] = null;
	    }
	}

	
	public CourseDBStructure(int courses) {
		
		 hashSize= courses;
	     hashTable= new LinkedList[hashSize];
	     
	     for(int i= 0; i< courses;i++) {
	    	   
	         hashTable[i] = null;
	     }
	}


	public void add(CourseDBElement element) {
		
		int test=0;
        test=((element.hashCode())%(hashSize)); 
        
        if (hashTable[test] == null) {
        	
            hashTable[test] = new LinkedList<>();
        }
        CourseDBElement existing;
		try {
			existing = get(element.getCRN());
			if(existing != null) {
				hashTable[test].remove(existing);
			}
		} catch (IOException e) {
			
		} 
       hashTable[test].add(element);

    		
	}

	
	@Override
	public CourseDBElement get(int crn) throws IOException {
		
		int indexTest = Integer.toString(crn).hashCode()%hashSize;
		
        if( hashTable[indexTest] == null) {
        	
            throw new IOException();
        }
        
        for(CourseDBElement i: hashTable[indexTest]) {
        	
            if (Integer.toString(crn).hashCode() == Integer.toString(i.getCRN()).hashCode()) 
            {
                return i;
            }
        }
        
        throw new IOException();	
	}

	
	@Override
	public int getTableSize() {
		
		return hashSize;
	}

}
