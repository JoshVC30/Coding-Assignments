/*
 * Class: CMSC140 CRN 30552
 * Instructor: Professor Justh
 * Project 5
 * Description: This program is meant to simulate a lottery game 
   where the user can get points if the numbers they guessed or the program 
   picked for them, match the randomly generated winning numbers.
 * Due Date: May 3, 2019
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Joshua Vazquez Correa
*/


#include <iostream>
#include<string>
#include<ctime>
#include<cstdlib>
#include<iomanip>

using namespace std;

int getArandNum(int, int);
void sortArray(int[], int);
void swap(int &, int &);
int compareArrays(int[], int[], int);
void displayArray(int[], int);

int  main()
{
	char wbChoice;															//store user's choice to pick 
	int wbNumber;
	char rbChoice;
	int rbNumber;
	const int W_MIN_VALUE = 1;
	const int W_MAX_VALUE = 69;
	const int R_MIN_VALUE = 1;
	const int R_MAX_VALUE = 26;
	int array1[6];
	int array2[6];
	int match;
	int points = 0;
	const int GRAND_PRIZE = 1000000000;

	const string PROG_NAME = "Joshua Vazquez Correa";
	const string DUE_DATE = "May 3, 2019";

	unsigned seed = static_cast<unsigned>(time(0));
	srand(seed);

	//display tittle
	cout << "Number Guessing Game\n" << "---------------------------\n" << endl;
	//display steps
	cout << "1. Select FIVE numbers from 1 to 69 for the white balls.\n" << "2. Select ONE number from 1 to 26 for the red Powerball.\n";
	cout << "3. Prize determined by how many of your numbers match the winning numbers.\n" << endl;

	//Prompt if user wants to pick the #s for white balls
	cout << "Do you want to self-pick your white ball numbers (Y or N): ";
	cin >> wbChoice;

	while (wbChoice != 'Y' && wbChoice != 'y' && wbChoice != 'N' && wbChoice != 'n')
	{
		cout << "ERROR \n";
		cout << "Do you want to self-pick your white ball numbers (Y or N): ";
		cin >> wbChoice;
	}

	//if the user chose to pick the numbers prompt for each ball
	if (wbChoice == 'Y' || wbChoice == 'y')
	{
		for (int n = 0; n < 5; n++)
		{
			cout << "Enter number " << n << " (between 1 and 69): ";
			cin >> wbNumber;
			array1[n] = wbNumber;

			while (wbNumber < 1 || wbNumber > 69)
			{
				cout << "!!ERROR!!  Please enter a number between 1 and 69: ";
				cin >> wbNumber;
				array1[n] = wbNumber;
			}
		}
	}

	//if the user didn't choose to pick the numbers 
	else if (wbChoice == 'N' || wbChoice == 'n')
	{
		for (int r = 0; r < 5; r++)
		{
			array1[r] = getArandNum(W_MIN_VALUE, W_MAX_VALUE);
		}
	}

	cout << "Do you want to self-pick your red ball number(Y or N): ";
	cin >> rbChoice;

	while (rbChoice != 'Y' && rbChoice != 'y' && rbChoice != 'N' && rbChoice != 'n')
	{
		cout << "ERROR \n";
		cout << "Do you want to self-pick your red ball number(Y or N): ";
		cin >> rbChoice;
	}

	//if the user chose to pick the numbers prompt for each ball
	if (rbChoice == 'Y' || rbChoice == 'y')
	{
		cout << "Enter POWERBALL number (between 1 and 26): ";
		cin >> rbNumber;
		array1[5] = rbNumber;

		while (rbNumber < 1 || rbNumber > 26)
		{
			cout << "!!ERROR!!  Please enter a number between 1 and 26: ";
			cin >> rbNumber;
			array1[5] = rbNumber;
		}
	}

	//if the user didn't choose to pick the numbers 
	else if (rbChoice == 'N' || rbChoice == 'n')
	{
		array1[5] = getArandNum(R_MIN_VALUE, R_MAX_VALUE);
	}

	for (int a = 0; a < 5; a++)
	{
		array2[a] = getArandNum(W_MIN_VALUE, W_MAX_VALUE);
	}

	array2[5] = getArandNum(R_MIN_VALUE, R_MAX_VALUE);

	match = compareArrays(array1, array2, 5);

	switch (match)
	{
	case 5:
	{
		if (match == 5 && (array1[5] == array2[5]))
		{
			points = GRAND_PRIZE;
		}
		else if (match == 5)
		{
			points = 1000000;
		}
	}
	break;

	case 4:
	{
		if (match == 4 && (array1[5] == array2[5]))
		{
			points = 50000;
		}
		else if (match == 4)
		{
			points = 100;
		}
	}
	break;

	case 3:
	{
		if (match == 3 && (array1[5] == array2[5]))
		{
			points = 100;
		}
		else if (match == 3)
		{
			points = 7;
		}
	}
	break;

	case 2:
	{
		if (match == 2 && (array1[5] == array2[5]))
		{
			points = 7;
		}
		else if (match == 2)
		{
			points = 7;
		}
	}
	break;

	case 1:
	{
		if (match == 1 && (array1[5] == array2[5]))
		{
			points = 4;
		}
	}
	break;

	case 0:
	{
		if (match == 0 && (array1[5] == array2[5]))
		{
			points = 4;
		}
	}
	break;

	default:
		break;
	}

	sortArray(array1, 5);
	sortArray(array2, 5);

	cout << "\n\n********** Game Report ************\n" << endl;

	cout << "You won " << fixed << showpoint << setprecision(2) << (float)points << " points for the game." << endl;

	cout << "\nHere are your numbers:" << endl;
	displayArray(array1, 6);
	cout << endl;

	cout << "\nHere are the winning numbers:" << endl;
	displayArray(array2, 6);
	cout << endl;


	cout << "\n**NOTE: The last number is the Power Ball number!!**\n" << "\n****************************" << endl;
	cout << "Thank you for using my program!!" << endl;
	cout << "PROGRAMMER : " << PROG_NAME << endl;
	cout << "CMSC140 Common Project 5" << endl;
	cout << "Due Date : " << DUE_DATE << endl;


	system("pause");
	return 0;
}

int getArandNum(int MinValue, int MaxValue)
{
	return rand() % (MaxValue - MinValue + 1) + MinValue;
}

void sortArray(int array[], int size)
{
	int minIndex, minValue;

	for (int i = 0; i < size - 1; i++)
	{
		minIndex = i;
		minValue = array[i];
		for (int e = i + 1; e < size; e++)
		{
			if (array[e] < minValue)
			{
				minValue = array[e];
				minIndex = e;
			}
		}
		swap(array[minIndex], array[i]);
	}
}

void swap(int &a, int &b)
{
	int temp = a;
	a = b;
	b = temp;
}

int compareArrays(int array1[], int array2[], int size)
{
	int match = 0;

	for (int m = 0; m < size; m++)
	{
		for (int i = 0; i < size; i++)
		{
			if (array1[m] == array2[i])
			{
				match++;
			}
		}
	}
	return match;
}

void displayArray(int array[], int size)
{
	for (int d = 0; d < size; d++)
	{
		cout << array[d] << " ";
	}

}