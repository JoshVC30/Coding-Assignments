import java.util.Random;
import java.text.DecimalFormat;
public class Ticket  
{
	Random random = new Random();
	DecimalFormat decimalFormat = new DecimalFormat("##.00");	
	private String name;
	private int speed;
	private int speedLimit;
	private boolean school;
	private boolean work;
	
	public Ticket(String name, int speed, int speedLimit, boolean schoolZone, boolean workZone) 
	{
		this.name = name;
		this.speed = speed;
		this.speedLimit = speedLimit;
		this.school = schoolZone;
		this.work = workZone;
	}
	
	public Ticket(String name, int speed, int speedLimit) 
	{
		this.name = name;
		this.speed = speed;
		this.speedLimit = speedLimit;
		this.school = false;
		this.work = false;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getSpeedLimit() {
		return speedLimit;
	}

	public void setSpeedLimit(int speedLimit) {
		this.speedLimit = speedLimit;
	}

	public boolean isSchoolZone() {
		return school;
	}

	public void setSchoolZone(boolean schoolZone) {
		this.school = schoolZone;
	}

	public boolean isWorkZone() {
		return work;
	}

	public void setWorkZone(boolean workZone) {
		this.work = workZone;
	}
	
	//variable
	double fine = 0.00;
	//int over = speed - speedLimit;
	public double calculateFine() 
	{
		if((speed - speedLimit) >= 1 && (speed - speedLimit) <= 10)
		{
			fine = 140.00;
			if(school == true) 
			{
				fine = 200.00;
			}
			if(work == true)
			{
				fine = 250.00;
			}
		}
		if((speed - speedLimit) >= 11 && (speed - speedLimit) <= 20)
		{
			fine = 195.00;
			if(school == true) 
			{
				fine = 300.00;
			}
			if(work == true)
			{
				fine = 350.00;
			}
		}
		if((speed - speedLimit) >= 21 && (speed - speedLimit) <= 30)
		{
			fine = 450.00;
		}
		if((speed - speedLimit) >= 31 && (speed - speedLimit) <= 40)
		{
			fine = 495.00;
		}
		if((speed - speedLimit) >= 41)
		{
			fine = 600.00;
		}
		
		return fine;
	}
		
	private int generateTicketNum() 			
	{	
		return random.nextInt(900000) + 100000;
	}
	
	private int generateCourtDate() 		
	{
		return random.nextInt(31) + 1;
	}
	
	//variable
	String ticketType;
	
	public String determineTicketType()	
	{
		if (fine <= 450.00) 
		{
			ticketType = "PAYABLE";
		}
		else if (fine >= 495.00) 
		{
			ticketType = "MUST APPEAR";
		}
		return ticketType;
	}
	
	public String getTicketType()			
	{
		return ticketType;
	}
	
	
	public String printNotice()		
	{
		String notice = "\nDepartment of Motor Vehicles\n" + "Automated Traffic Enforcement\n" 
						+ "\n\nDear " + this.name + ",\n\n" + "Please pay the following speeding fine of $" 
						+ decimalFormat.format(calculateFine()) + " to the DMV within 10 days of \nreceiving "
						+ "this notice to avoid a "
						+ "driver's license suspension. You are being fined \nfor going "
						+ this.speed + " MPH in a " + this.speedLimit + " MPH";
		if(work = true)
		{
			notice += " work ";
		}
		
		if(school = true)
		{
			notice += " school ";
		}
		
		notice += " zone.\n\n" + "Ticket Type: " + determineTicketType();
		if(ticketType == "MUST APPEAR") 
		{
			notice += "\nYou must appear at the County Court House on October " + generateCourtDate() 
					+ ", 2018.\n";
		}
		notice += "\nTicket Number: " + generateTicketNum() + "\n\nReturned checks are subject "
		+ "to a returned check fee of $35.00\n\n" + "Sincerely\n\n" + "Joshua Vazquez Correa";
		
		return notice;
	}
	@Override
	public String toString() {
		return "Ticket [random=" + random + ", name=" + name + ", speed=" + speed + ", speedLimit=" + speedLimit
				+ ", school=" + school + ", work=" + work + ", fine=" + fine + ", ticketType=" + ticketType + "]";
	}

}
