import java.util.Scanner;
public class TicketDriver {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		String name;
		String schoolAnswer;
		String workAnswer;
		String another;
		int speed;
		int speedLimit;
		boolean schoolZone;
		boolean workZone;
		

		//print a header
		System.out.println("Ticket Manager\n");
		
		do {
		//prompt the user for the information about a ticket
		System.out.println("Enter the name of the violator: ");
		name = scan.nextLine();
		System.out.println("Enter the speed of the violator (>0): ");
		speed = scan.nextInt();
		while(speed <= 0)
		{
			System.out.println("Enter the speed of the violator (>0): ");
			speed = scan.nextInt();
		}
		
		System.out.println("Enter the speed limit (>0,<=80): ");
		speedLimit = scan.nextInt();
		while(speedLimit <= 0 || speedLimit > 80)
		{
			System.out.println("Enter the speed limit (>0,<=80): ");
			speedLimit = scan.nextInt();
		}
		
		System.out.print("Was this in a school zone (Y/N): ");
		schoolAnswer = scan.nextLine();
		
		while(!schoolAnswer.equals("Y") && !schoolAnswer.equals("N"))
		{
			System.out.print("Was this in a school zone (Y/N): ");
			schoolAnswer = scan.nextLine();
		}
		if(schoolAnswer.equals("Y")) 
		{
			schoolZone = true;
		}
		else
		{
			schoolZone = false;
		}
			
		System.out.println("Was this in a work zone (Y/N): ");
		workAnswer = scan.nextLine();
		while(!workAnswer.equals("Y") && !workAnswer.equals("N"))
		{
			System.out.println("Was this in a work zone (Y/N): ");
			workAnswer = scan.nextLine();
		}
		if(workAnswer.equals("Y")) 
		{
			workZone = true;
		}
		else
		{
			workZone = false;
		}	
		
		
		Ticket ticket = new Ticket(name, speed, speedLimit, schoolZone, workZone);
		System.out.println(ticket.printNotice());
		
		System.out.println("Do you want to enter another ticket? (Y/N) ");
		another = scan.nextLine();
		while(!another.equals("Y") && !another.equals("N"))
		{
			System.out.println("Do you want to enter another ticket? (Y/N) ");
			another = scan.nextLine();
		}
		
		} while(another.equals("Y"));

		System.out.println("Exiting the Ticket Manager");


		scan.close();
	}

}
