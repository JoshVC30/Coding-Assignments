import java.util.Scanner;
/*This assignment is meant to take the users 
loan amount, interest, and number of payments 
and calculate the monthly payment
Programmer: Joshua Vazquez Correa
*/

public class Assignment {
	
		public static void main(String[] args) 
		{
			//integer
			double  loanAmount, interestRate, numberOfPayment, payment;
			
			Scanner scan = new Scanner(System.in);
			
			//system.out
			System.out.println("Loan Calculator");
			
			//system.out
			System.out.println("\n\nPlease enter a loan amount: ");
			//system.in
			loanAmount = scan.nextDouble();
			
			//verify input is positive
			while(loanAmount<0)
			{
				System.out.println("Please enter a positive number for the loan amount: ");
				loanAmount = scan.nextDouble();
			}
			
			//system.out
			System.out.println("Please enter an interest rate: ");
			//system.in
			interestRate = scan.nextDouble();
			
			//verify input is positive
			while(interestRate<0)
			{
				System.out.println("Please enter a positive number for the ineterest rate: ");
				interestRate = scan.nextDouble();
			}
			
			//system.out
			System.out.println("Please enter the desired number of payments: ");
			//system.in
			numberOfPayment = scan.nextDouble();
			
			//verify input is positive
			while(numberOfPayment<0)
			{
				System.out.println("Please enter a positive number for the number of payment: ");
				numberOfPayment = scan.nextDouble();
			}
			
			//calculate monthly payment
			payment = loanAmount * (((interestRate/100)/12.0)/(1- Math.pow((1+((interestRate/100)/12.0)), -numberOfPayment)));
			
			//system.out
			System.out.printf("Total monthly payment for a loan of $" + loanAmount + " is: $ %.2f\n", payment);
			
			scan.close();
		}


}
