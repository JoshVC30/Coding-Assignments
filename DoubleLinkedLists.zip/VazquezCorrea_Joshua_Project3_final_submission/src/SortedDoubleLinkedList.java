/**
 * @author joshua vazquez correa
 */
import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T>{

	/**
	 * Inserts the specified element at the correct position in the sorted list.
	 * @param data
	 * @return a reference to the current object
	 */
	public SortedDoubleLinkedList<T> add(T data) {
		
		if (data == null) {
			
			return this;
		}
	
		Node newnode = new Node(data, null, null);
		
		if (head == null) {
			
			head = tail = new Node(data, null, null);
		}
		
		else {
			
			if (comp.compare(data, head.item) <= 0) {
				
				newnode.next = head;
				head = newnode;
			}
			
			else if (comp.compare(data, tail.item) >= 0) {
				
				tail.next = newnode;
				tail = newnode;
			}
			
			else {
				
				Node next = head.next;
				
				Node prev = head;
				
				while (comp.compare(data, next.item) > 0) {
					
					prev = next;
					next = next.next;
				}
				
				prev.next = newnode;
				newnode.next = next;
					
			}
			
		}
		
		size++;
		
		return this;
	}
	
	
	public BasicDoubleLinkedList<T> addToEnd(T data) 
	{
		
		throw new UnsupportedOperationException("Invalid operation for sorted list");
	}
	
	
	public BasicDoubleLinkedList<T> addToFront(T data) {
		
		throw new UnsupportedOperationException("Invalid operation for sorted list");
	}
	
	
	public ListIterator<T> iterator() {
		
		return new DoubleLinkedListIterator();
	}
	
	/**
	 * Removes the first instance of the targetData from the list.
	 * @param targetData
	 * @param comparator
	 * @return
	 */
	public SortedDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator) {
		
		Node next = head;
		Node prev = null;
		
		while (next != null) {
		
			if (comparator.compare(next.item, targetData) == 0) {
				
				size--;
				
				if (prev != null) {
					
					prev.next = next.next;
				}
				
				else {
					
					head = next.next;
				}
				
				if (next == tail) {
					
					tail = prev;
				}
			}
			
			prev = next;
			next = next.next;
		}
		
		return this;
	}

	// creates empty list
	Comparator<T> comp = null;
	
	
	/**
	 * 
	 * @param comparator
	 */
	public SortedDoubleLinkedList(Comparator<T> comparator) {
		
		comp = comparator;
	}
}