/**
 * @author joshua vazquez correa
 */

import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> extends Object implements Iterable<T>{
	
	
	protected int size;
	protected Node head, tail;
	
	
	public BasicDoubleLinkedList(){		
		size = 0;
		head = tail = null;
	}
	
	
	protected class Node {
		
		protected T item;
		protected Node next, previous;
		
		//node constructor
		protected Node(T item, Node next, Node previous) {
			
			this.item = item;
			this.next = next;
			this.previous = previous;
		}
	}
	
	
	/**
	 * Returns the number of nodes in the list.
	 * @return size
	 */
	public int getSize() {
		return size;
	}
	
	
	/**
	 * Adds an element to the end of the list and updated the size of the list
	 * @param data
	 */
	public BasicDoubleLinkedList<T> addToEnd​(T data) {
		Node temp = new Node(data, null, tail);
		
		if (tail != null) {
			tail.next = temp;
		}
		
		tail = temp;
		
		if (head == null) {
			head = temp;
		}
		
		size++;
		
		return this;
	}
	
	
	/**
	 * Adds element to the front of the list and updated the size of the list
	 * @param data
	 * @return
	 */
	public BasicDoubleLinkedList<T> addToFront​(T data) {
		Node temp = new Node(data, head, null);
		
		if (head != null) {			
			head.previous = temp;
		}	
		
		head = temp;
		
		if (tail == null) {		
			tail = temp;
		}
		
		size++;		
		return this;
	}
	
	
	/**
	 * Returns but does not remove the first element from the list
	 * @return the data element or null
	 */
	public T getFirst() {
		return head.item;
		
	}
	
	
	/**
	 * Returns but does not remove the last element from the list.
	 * @return the data element or null
	 */
	public T getLast() {
		return tail.item;		
	}
	
	
	/**
	 * This method returns an object of the DoubleLinkedListIterator. 
	 * (the inner class that implements java's ListIterator interface)
	 * @return a ListIterator object
	 */
	public ListIterator<T> iterator(){
		
		return new DoubleLinkedListIterator();	
	}
	
	
	/**
	 * Removes the first instance of the targetData from the list.
	 * @param targetData
	 * @param comparator
	 * @return a node containing the targetData or null
	 */
	public BasicDoubleLinkedList<T> remove​(T targetData, Comparator<T> comparator){
		Node prev = null, curent = head;
		
		while (curent != null) {
			
			if (comparator.compare(curent.item, targetData) == 0) {
				
				if (curent == head) {
					head = head.next;
					curent = head;
				}
				else if (curent == tail) {
					curent = null;
						tail = prev;
						prev.next = null;
				}
				else {
					prev.next = curent.next;
					curent = curent.next;
				}
				size--;
			}
			else {
				prev = curent;
				curent = curent.next;
			}
		}
		return this;		
	}
	
	
	/**
	 * Removes and returns the first element from the list.
	 * @return data element or null
	 */
	public T retrieveFirstElement(){
		if (size == 0) {
			
			throw new NoSuchElementException("Linked list is empty");
		}
		
		Node temp = head;
		head = head.next;
		head.previous = null;
		size--;
		
		return temp.item;
		
	}
	
	
	/**
	 * Removes and returns the last element from the list. 
	 * @return data element or null
	 */
	public T retrieveLastElement() {
		
		if (head == null) {
			throw new NoSuchElementException("Linked list is empty");
		}
		
		Node curentNode = head;
		Node previousNode = null;
		
		while (curentNode != null) {
			
			if (curentNode.equals(tail)) {	
				tail = previousNode;
				break;
			}
			
			previousNode = curentNode;
			curentNode = curentNode.next;
		}
		
		size--;
		return curentNode.item;
	}
	
	
	/**
	 * Returns an arraylist of all the items in the Double Linked list
	 * @return an arraylist of the items in the list
	 */
	public ArrayList<T> toArrayList(){
		ArrayList<T> temp = new ArrayList<T>();
		ListIterator<T> iterator1 = new DoubleLinkedListIterator();
		
		while (iterator1.hasNext()) {	
			temp.add(iterator1.next());
		}
		
		return temp;
		
	}

	
	/**
	 * 
	 * A generic inner class named DoubleLinkedListIterator that implements 
	 * java’s ListIterator interface (for the iterator method).
	 *
	 */
	public class DoubleLinkedListIterator implements ListIterator<T> {
		
		private Node curent;
		private Node last;
		
		//Constructor to initialize the current pointer to the head of the BasicDoubleLinkedList.
		public DoubleLinkedListIterator() {
			curent = head;
			last = null;
		}
		
		
		public boolean hasNext() {
			return curent!=null;
		}
		
		public T next() {	
			
			if(curent != null) {	
				T returnData = curent.item;
				last = curent;
				curent = curent.next;
				
				if(curent != null) {
					curent.previous = last;
				}
			return returnData;	
			} 
			else{
				throw new NoSuchElementException();
			}
		}
		
		public boolean hasPrevious() {	
			return last!=null;
		}
		
		public T previous() {
			
			if(last != null) {
				
				curent = last;
				last= curent.previous;
				T returnData = curent.item;
				
				return returnData;
			}
			
			else {			
				throw new NoSuchElementException();
			}
		}
		
		public void remove() {	
			throw new UnsupportedOperationException();
		}
		
		public void add(T arg0) {
			throw new UnsupportedOperationException();
		}
		
		public int nextIndex() {		
			throw new UnsupportedOperationException();
		}
	
		public int previousIndex() {	
			throw new UnsupportedOperationException();
		}

		public void set(T arg0) {	
			curent.item = arg0;
		}
			
	}
}