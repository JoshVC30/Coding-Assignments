//@author Joshua Vazquez Correa
public class Adult extends Ticket
{
	
	public Adult(String movieName, String rating, int day, int time, String feature) 
	{
		super(movieName, rating, day, time, feature, "Adult");
	}
	
	@Override
	public double calculateTicketPrice() 
	{
		double priceTtl = 0.0;
		
		if(getTime() < 18)
		{
			priceTtl = 10.50;
		}
		else
		{
			priceTtl = 13.50;
		}
		switch(getFormat()) 
		{
			case IMAX: priceTtl += 3.0;
				break;
			case THREE_D: priceTtl += 2.5;
				break;
			case NONE: priceTtl += 0;
		}
		
		priceTtl +=  priceTtl * TAX;
		setTicketPrice(priceTtl);
		
		return priceTtl;
	}
	
	@Override
	public int getId()
	{
		return -1;
	}
	
	public String toString()
	{
		String toString = "ADULT";
		
		if(getFormat() == Format.IMAX) 
		{
			toString += " IMAX";
		}
		else if(getFormat() == Format.THREE_D)
		{
			toString += " 3D";
		}
		
		toString += super.toString();
		
		return toString;
	}
	
}
