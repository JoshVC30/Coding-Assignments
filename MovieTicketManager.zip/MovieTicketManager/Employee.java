//@author Joshua Vazquez Correa
public class Employee extends Ticket
{
	private int employeeId;
	private int movieVisits;
	
	public Employee(String movieName, String rating, int day, int time, String feature, int employeeId, int movieVisits) 
	{
		super(movieName, rating, day, time, feature, "Employee");
		
		this.employeeId = employeeId;
		this.movieVisits = movieVisits;
	}
	
	public double calculateTicketPrice() 
	{
		double priceTtl = 0.0;
		if(movieVisits < 2)
		{
			priceTtl = 0.00;
		}
		else 
		{
			if(getTime() < 18)
			{
				priceTtl = 5.25;
			}
			else
			{
				priceTtl = 6.75;
			}
			switch(getFormat()) 
			{
				case IMAX: priceTtl += 3.0;
					break;
				case THREE_D: priceTtl += 2.5;
					break;
				case NONE: priceTtl += 0;
			}
		}
		
		priceTtl +=  priceTtl * TAX;
		setTicketPrice(priceTtl);
		
		return priceTtl;
	}
	
	public int getId()
	{
		return employeeId;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}
	
	public String toString()
	{
		String toString = "EMPLOYEE-" + employeeId;
		
		if(getFormat() == Format.IMAX) 
		{
			toString += " IMAX";
		}
		else if(getFormat() == Format.THREE_D)
		{
			toString += " 3D";
		}
		
		toString += super.toString();
		
		return toString;
	}

	
}
