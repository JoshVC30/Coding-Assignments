
public class MoviePass extends Ticket
{
	private int moviePassId;
	private int movieVisits;
	private int sameMovieVisits;
	private int moviesPerDay;
	
	public MoviePass(String movieN, String rating, int date, int time, String feature, int moviePassId, int movieVisits, int sameMovieVisits, int moviesPerDay) 
	{
		super(movieN, rating, date, time, feature, "MoviePass");
		
		this.moviePassId = moviePassId;
		this.movieVisits = movieVisits;
		this.sameMovieVisits = sameMovieVisits;
		this.moviesPerDay = moviesPerDay;
	}
	
	public double calculateTicketPrice() 
	{
		double priceTtl = 0.0;
		
		if(movieVisits < 1 && getFormat() == Format.NONE) 
		{
			priceTtl = 9.99;
		}
		else 
		{
			if(movieVisits < 2 && sameMovieVisits < 1 && getFormat() == Format.NONE) 
			{
				priceTtl = 0.0;
			}
			else 
			{
				if(getTime() < 18)
				{
					priceTtl = 10.50;
				}
				else
				{
					priceTtl = 13.50;
				}
				switch(getFormat()) 
				{
					case IMAX: priceTtl += 3.00;
						break;
					case THREE_D: priceTtl += .50;
						break;
					case NONE: priceTtl += 0;
				}
				
				priceTtl +=  priceTtl * TAX;
			}
		}	
		
		setTicketPrice(priceTtl);
		
		return priceTtl;
	}
	
	public int getId()
	{
		return moviePassId;
	}
	
	public String toString()
	{
		String toString = "CHILD";
		if(getFormat() == Format.IMAX) 
		{
			toString += " IMAX";
		}
		else if(getFormat() == Format.THREE_D)
		{
			toString += " 3D";
		}
		
		toString += super.toString();
		
		return toString;
	}

	public int getMovieVisits() {
		return movieVisits;
	}

	public int getSameMovieVisits() {
		return sameMovieVisits;
	}

	public int getMoviesPerDay() {
		return moviesPerDay;
	}
}
