import java.text.NumberFormat;

//@author Joshua Vazquez Correa

public abstract class Ticket 
{
	private Format format;
	private String movieName;
	private String rating;
	private int day;
	private int time;
	private String type;
	private double ticketPrice;
	
	protected final double TAX = 0.096;
	
	private NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
	
	public abstract double calculateTicketPrice();
	
	public abstract int getId();	
	
	public Ticket()
	{
		this.format = Format.NONE;
		this.movieName = "";
		this.rating = "";
		this.day = 0;
		this.time = 0;
		this.type = "";
	}
	
	public Ticket(String movieName, String rating, int day, int time, String feature, String type)
	{
		this.movieName = movieName;
		this.rating = rating;
		this.day = day;
		this.time = time;
		this.type = type;
		
		switch(feature)
		{
			case "IMAX": this.format = Format.IMAX;
				break;
			case "3D": 
			case "THREE_D": this.format = Format.THREE_D;
				break;
			case "NONE": this.format = Format.NONE;
				break;
		}
	}
	
	public String toString()
	{
		return " Movie: " + this.movieName + " Rating: " + this.rating + " Day: " + this.day  + " Time: " + this.time + " Price: " + currencyFormat.format(ticketPrice);
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int d) {
		this.day = d;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int t) {
		this.time = t;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public Format getFormat() {
		return format;
	}
	
	public void setFeature(String f) 
	{
		if(f.equalsIgnoreCase("IMAX")) 
		{
			this.format = Format.IMAX;
		}
		else if(f.equalsIgnoreCase("THREE_D")) 
		{
			this.format = Format.THREE_D;
		}
		else if(f.equalsIgnoreCase("NONE")) 
		{
			this.format = Format.NONE;
		}
	}
	

}
