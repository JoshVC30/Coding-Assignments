
import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MovieTicketManagerTestSTUDENT{
	private MovieTicketManager ticketList;
	

	@Before
	public void setUp() throws Exception {
		ticketList = new MovieTicketManager();
		
		//add adults
		ticketList.addTicket("Avengers 1", "PG13", 4,21,"NONE","Adult",0);
	}

	@After
	public void tearDown() throws Exception {
		ticketList=null;
	}


	/**
	 * Test adding tickets of the "adult" type of tickets
	 */
	@Test
	public void testAddTicket() {
		MovieTicketManager tickets = new MovieTicketManager();
		//adult ticket
		assertEquals(14.80,tickets.addTicket("Joker", "R", 15,20,"NONE","Adult",0),.01);
	}

	/**
	 * Test the total of tickets sales for the month
	 */
	@Test
	public void testTotalSalesMonth() {
		assertEquals(14.796,ticketList.totalSalesMonth(),.1);
		
	}

}
