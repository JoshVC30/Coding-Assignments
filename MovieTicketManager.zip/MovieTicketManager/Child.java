//@author Joshua Vazquez Correa
public class Child extends Ticket
{
	public Child(String movieName, String rating, int day, int time, String feature) {
		super(movieName, rating, day, time, feature, "Child");
	}
	
	public double calculateTicketPrice() 
	{
		double priceTtl = 0.0;
		
		if(getTime() < 18)
		{
			priceTtl = 5.75;
		}
		else
		{
			priceTtl = 10.75;
		}
		switch(getFormat()) 
		{
			case IMAX: priceTtl += 2.00;
				break;
			case THREE_D: priceTtl += 1.50;
				break;
			case NONE: priceTtl += 0;
		}
		
		priceTtl +=  priceTtl * TAX;
		setTicketPrice(priceTtl);
		
		return priceTtl;
	}
	
	public int getId()
	{
		return -1;
	}
	
	public String toString()
	{
		String toString = "CHILD";
		if(getFormat() == Format.IMAX) 
		{
			toString += " IMAX";
		}
		else if(getFormat() == Format.THREE_D)
		{
			toString += " 3D";
		}
		
		toString += super.toString();
		
		return toString;
	}
}
