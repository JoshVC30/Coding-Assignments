//@author Joshua Vazquez Correa

import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MovieTicketManager implements MovieTicketManagerInterface
{
	private ArrayList<Ticket> ticketList;
	private NumberFormat currencyFormat;
	
	public MovieTicketManager()
	{
		ticketList = new ArrayList<Ticket>();
		currencyFormat = NumberFormat.getCurrencyInstance();
	}
	
	public int numVisits(int id)
	{
		int ttlVisits = 0;
		
		for(int i = 0; i < ticketList.size(); i++)
		{
			if(ticketList.get(i).getId() == id)
			{
				ttlVisits++;
			}
		}
	
		return ttlVisits;
	}
	
	public int numThisMovie(int id, String movie)
	{
		int ttlThisMovie = 0;
		
		for(int i = 0; i < ticketList.size(); i++)
		{
			if(ticketList.get(i).getMovieName().equalsIgnoreCase(movie) && ticketList.get(i).getId() == id)
			{
				ttlThisMovie++;
			}
		}
		
		return ttlThisMovie;
	}
	
	public int numMoviesToday(int id, int date)
	{
		int ttlMoviesToday  = 0;
		
		for(int i = 0; i < ticketList.size(); i++) 
		{
			if(ticketList.get(i).getDay() == date && ticketList.get(i).getId() == id)
			{
				ttlMoviesToday++;
			}
		}
	
		return ttlMoviesToday;
	}
	
	public double addTicket(String movieN, String rating, int d, int t, String f, String type, int id)
	{
		int numVis = numVisits(id);
		int numThisMovie = numThisMovie(id, movieN);
		int numMoviesToday = numMoviesToday(id, d);
		Ticket visitor;
		
		if(type.equalsIgnoreCase("Adult")) 
		{
			visitor = new Adult(movieN, rating, d, t, f);
			ticketList.add(visitor);
			
			return visitor.calculateTicketPrice();
		}
		else if(type.equalsIgnoreCase("Child")) 
		{
			visitor = new Child(movieN, rating, d, t, f);
			ticketList.add(visitor);
			
			return visitor.calculateTicketPrice();
		}
		else if(type.equalsIgnoreCase("Employee")) 
		{
			visitor = new Employee(movieN, rating, d, t, f, id, numVis);
			ticketList.add(visitor);
			
			return visitor.calculateTicketPrice();
		}
		else if(type.equalsIgnoreCase("MoviePass")) 
		{
			visitor = new MoviePass(movieN, rating, d, t, f, id, numVis, numThisMovie, numMoviesToday);
			ticketList.add(visitor);
			
			return visitor.calculateTicketPrice();
		}
		
		return -1;
	}
	
	public double totalSalesMonth()
	{
		double ttlSales = 0.0;
		
		for(int i = 0; i < ticketList.size(); i++) 
		{
			ttlSales += ticketList.get(i).getTicketPrice();
		}
		
		return ttlSales;
	}
	
	public String monthlySalesReport()
	{
		double totalSales = totalSalesMonth();
		int adultCount = 0;
		int childCount = 0; 
		int employeeCount = 0;
		int moviePassCount = 0;
		double salesAdult = 0.0;
		double salesChild = 0.0;
		double salesEmployee = 0.0;
		double salesMoviePass = 0.0;
		
		//DecimalFormat df = new DecimalFormat("###.##");
		String salesReport = "       Monthly Sales Report\n\n" + "\t\t     Sales\t\tNumber\n";
		
		for(int i = 0; i < ticketList.size(); i++) 
		{
			if(ticketList.get(i).getType().equalsIgnoreCase("Adult")) 
			{
				salesAdult += ticketList.get(i).getTicketPrice();
				adultCount++;
			}
			
			if(ticketList.get(i).getType().equalsIgnoreCase("Child")) 
			{
				salesChild += ticketList.get(i).getTicketPrice();
				childCount++;
			}
			
			if(ticketList.get(i).getType().equalsIgnoreCase("Employee")) 
			{
				salesEmployee += ticketList.get(i).getTicketPrice();
				employeeCount++;
			}			
			
			if(ticketList.get(i).getType().equalsIgnoreCase("MoviePass")) 
			{
				salesMoviePass += ticketList.get(i).getTicketPrice();
				moviePassCount++;
			}
		}
		
		salesReport += "ADULT          " + currencyFormat.format(salesAdult) + "\t\t" + adultCount
					+ "\nCHILD           " + currencyFormat.format(salesChild) + "\t\t" + childCount
					+ "\nEMPLOYEE    " + currencyFormat.format(salesEmployee) + "\t\t" + employeeCount
					+ "\nMOVIEPASS  " + currencyFormat.format(salesMoviePass) + "\t" + moviePassCount
					+ "\n\nTotal Monthly Sales: " + currencyFormat.format(totalSales);
		
		return salesReport;
	}
	
	public ArrayList<String> get3DTickets()
	{
		ArrayList<String> THREE_D_Ticket = new ArrayList<String>();
		sortByDay();
		
		for(int i = 0; i < ticketList.size(); i++) 
		{
			if(ticketList.get(i).getFormat() == Format.THREE_D) 
			{
				THREE_D_Ticket.add(ticketList.get(i).toString());
			}
		}
		
		return THREE_D_Ticket;
	}
	
	public ArrayList<String> getAllTickets()
	{
		ArrayList<String> allTickets = new ArrayList<String>();
		sortByDay();
		
		for(int i = 0; i < ticketList.size(); i++) 
		{
			allTickets.add(ticketList.get(i).toString());
		}
		
		return allTickets;
	}
	
	public ArrayList<String> getMoviePassTickets()
	{
		ArrayList<String> moviePassTickets = new ArrayList<String>();
		sortById();
		
		for(int i = 0; i < ticketList.size(); i++) 
		{
			if(ticketList.get(i).getType().equalsIgnoreCase("MOVIEPASS")) 
			{
				moviePassTickets.add(ticketList.get(i).toString());
			}
		}
		
		return moviePassTickets;
	}
	
	public void readFile(File file) throws FileNotFoundException
	{
		Scanner scan = new Scanner(file);
		
		String line, movieName, rating, feature, type;
		int day, time;
		int ID = 0;
		String[] token;
		
		while(scan.hasNext()) 
		{			
			line = scan.nextLine();
			
			StringTokenizer strTokenizer = new StringTokenizer(line, ":");
			
			movieName = strTokenizer.nextToken();
			rating = strTokenizer.nextToken();
			
			day = Integer.parseInt(strTokenizer.nextToken());
			time = Integer.parseInt(strTokenizer.nextToken());
			
			feature = strTokenizer.nextToken();
			type = strTokenizer.nextToken();
			
			if(type.equalsIgnoreCase("Employee") || type.equalsIgnoreCase("MoviePass")) 
			{
				ID = Integer.parseInt(strTokenizer.nextToken());
			}
			
			addTicket(movieName, rating, day, time, feature, type, ID);
		}
		
		scan.close();
	}
	
	private void sortByDay()
	{
		Ticket temp;
		
		for(int i = 1; i < ticketList.size(); i++) 
		{
			for(int j = i; j > 0; j--) 
			{
				if(ticketList.get(j).getDay() < ticketList.get(j-1).getDay()) 
				{
					temp = ticketList.get(j-1);
					
					ticketList.set(j-1, ticketList.get(j));
					ticketList.set(j, temp);
				}
			}
		}
	}

	private void sortById()
	{
		Ticket temp;
		
		for(int i = 1; i < ticketList.size(); i++) 
		{
			for(int j = i; j > 0; j--) 
			{
				if(ticketList.get(j).getId() < ticketList.get(j-1).getId()) 
				{
					temp = ticketList.get(j-1);
					
					ticketList.set(j-1, ticketList.get(j));
					ticketList.set(j, temp);
				}
			}
		}
	}
}
