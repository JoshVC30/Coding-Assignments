//@author Joshua Vazquez Correa
public enum Format 
{
	IMAX, THREE_D, NONE;
}
