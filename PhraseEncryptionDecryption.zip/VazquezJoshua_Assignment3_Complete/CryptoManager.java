/**
 * A Java program to encrypt and decrypt a phrase using the caesar and bellaso approaches.
 * 
 * @author Joshua Vazquez Correa
 */

public class CryptoManager {
	
	private static final char LOWER_BOUND = ' ';
	private static final char UPPER_BOUND = '_';
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_BOUND and UPPER_BOUND characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean stringInBounds(String plainText)
	{
		boolean inBounds = false;
		
		for(int amount = 0; amount < plainText.length(); amount++)
		{
			if(plainText.charAt(amount) >= LOWER_BOUND && plainText.charAt(amount) <= UPPER_BOUND) 
			{
				inBounds = true;
			}
			else
			{
				inBounds = false;
			}
		}		
		return inBounds;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String encryptCaesar(String plainText, int key) 
	{
		String eCaesar = "";
		for(int i = 0; i < plainText.length(); i++) 
		{
			while(key > RANGE) 
			{
				key -= RANGE;		
			}
			eCaesar += (char)(plainText.charAt(i) + key);
		}
		return eCaesar;
	}

	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String decryptCaesar(String encryptedText, int key) 
	{
		String dCaesar = "";
		
		for(int i = 0; i < encryptedText.length(); i++) 
		{
			while(key > RANGE) 
			{
				key += RANGE;		
			}
			dCaesar += (char)(encryptedText.charAt(i) - key);
		}
		return dCaesar;
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String encryptBellaso(String plainText, String bellasoStr) 
	{
		String eBellaso = "";
		int bellasoStrLength = bellasoStr.length();
		
		for(int i = 0; i < plainText.length(); i++)
		{
			char thisChar = plainText.charAt(i);
			int encryptedCharInt = ((int)thisChar + (int)bellasoStr.charAt(i%bellasoStrLength));
			while(encryptedCharInt > UPPER_BOUND)
			{
				encryptedCharInt -= RANGE;
			}
			eBellaso += (char)encryptedCharInt;
		}
		return eBellaso;
	}
	
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String decryptBellaso(String encryptedText, String bellasoStr)
	{
		String dBellaso = "";
		int bellasoStrLength = bellasoStr.length();
		
		for(int i = 0; i < encryptedText.length(); i++)
		{
			char thisChar = encryptedText.charAt(i);
			int encryptedCharInt = ((int)thisChar - (int)bellasoStr.charAt(i%bellasoStrLength));
			while(encryptedCharInt < LOWER_BOUND)
			{
				encryptedCharInt += RANGE;
			}
			dBellaso += (char)encryptedCharInt;
		}
		return dBellaso;
	}
}
