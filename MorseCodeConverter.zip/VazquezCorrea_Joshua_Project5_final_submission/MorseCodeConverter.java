/**
 * @author joshua  vazquez correa
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter {
	
	private static MorseCodeTree morseCodeTree = new MorseCodeTree();

	/**
	 * constructor
	 */
	public MorseCodeConverter() {
		
	}

	
	/**
	 * returns a string with all the data in the tree in LNR order with an space in between them. 
	 * @return the data in the tree in LNR order separated by a space.
	 */
	public static String printTree() {
	
		ArrayList<String> arrayListTree = new ArrayList<>();

		arrayListTree = morseCodeTree.toArrayList();

		String stringTree = "";

		for (String letter : arrayListTree) {
			stringTree += letter + " ";
		}

		return stringTree;
	}

	
	/**
	 * Converts Morse code into English.
	 * @param code - the morse code
	 * @return the English translation
	 */
	public static String convertToEnglish(String code) {
		
		
		String wordInEngl = "";
		

		String[] wordsInMorseArray = code.split(" / ");

		for (String wordInMorse : wordsInMorseArray) {

			String[] lettersInMorseArray = wordInMorse.split(" ");
		

			for (String letter : lettersInMorseArray) {
			
					wordInEngl+= morseCodeTree.fetch​(letter);
				
			}

			wordInEngl += " ";
		}
		
		return wordInEngl.trim();
	
	}

	/**
	 * Converts a file of Morse code into English 
	 * @param codeFile - name of the File that contains Morse Code
	 * @return the English translation of the file
	 * @throws FileNotFoundException
	 */
	public static String convertToEnglish(File codeFile) throws FileNotFoundException {
		
		String sentenceInMorse = "";
		String sentenceInEnglish;

		Scanner sc = new Scanner(codeFile);

		while (sc.hasNext()) {
			sentenceInMorse += sc.nextLine();
		}

		sentenceInEnglish = convertToEnglish(sentenceInMorse);
		
		sc.close();
		
		return sentenceInEnglish;
		
	}

	
}
