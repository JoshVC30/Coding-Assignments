/**
 * @author joshua  vazquez correa
 */


import java.util.ArrayList;

public class MorseCodeTree {
	
	private TreeNode<String> root = null;
	String letterSearched = "";
	
	/**
	 * constructor - calls the buildTree method
	 */
	public MorseCodeTree() {
		buildTree();
	}
	
	/**
	 * Returns a reference to the root
	 * @return reference to root
	 */
	public TreeNode<String> getRoot(){
		return root;
		
	}
	
	/**
	 * sets the root of the MorseCodeTree
	 * @param newNode - a newNode that will be the root of MorseCodeTree
	 */
	public void setRoot​(TreeNode<String> newNode) {
		this.root = newNode;
	}
	
	/**
	 * Adds element to the correct position in the tree based on the code 
	 * This method will call the recursive method addNode
	 * @param code - the code for the new node to be added, example ".-."
	 * @param letter
	 */
	public void insert​(String code, String letter) {
		addNode​(root, code, letter);
	}
	
	/**
	 * This is a recursive method that adds element to the correct position in the tree based on the code. 
	 * A '.' (dot) means traverse to the left. A "-" (dash) means traverse to the right. 
	 *  
	 * @param root - the root of the tree for this particular recursive instance of addNode
	 * @param code - the code for this particular recursive instance of addNode
	 * @param letter - the data of the new TreeNode to be added
	 */
	public void addNode​(TreeNode<String> root, String code, String letter) {
		if (code.length() == 1) {
			TreeNode<String> node = new TreeNode<String>(letter);

			if (code.equals(".")) {
				root.leftChild = new TreeNode<String>(node);
			
			} else if (code.equals("-")) {
				root.rightChild = new TreeNode<String>(node);
			
			}
		
		}

		else if (code.length() > 1) {
			String newCode = code.substring(1);

			if (code.charAt(0) == '.') {
				addNode​(root.leftChild, newCode, letter);
		
			} else if (code.charAt(0) == '-') {
				addNode​(root.rightChild, newCode, letter);
			
			}
		}
	}
	
	
	/**
	 * Fetch the data in the tree based on the code This method will call the recursive method fetchNode
	 * @param code - the code that describes the traversals to retrieve the string (letter)
	 * @return the string (letter) that corresponds to the code
	 */
	public String fetch​(String code){
		
		return fetchNode​(root, code);
		
	}
	
	/**
	 * This is the recursive method that fetches the data of the TreeNode that corresponds with the code 
	 * A '.' (dot) means traverse to the left. A "-" (dash) means traverse to the right. 
	 * 
	 * @param root - the root of the tree for this particular recursive instance of addNode
	 * @param code - the code for this particular recursive instance of addNode
	 * @return the string (letter) corresponding to the code
	 */
	public String fetchNode​(TreeNode<String> root, String code){
		
		
		
		if (code.length() == 1) {

			if (code.equals(".")) {
			letterSearched = root.leftChild.getData();
			
			} else if (code.equals("-")) {
				letterSearched = root.rightChild.getData();

			}
		}

		else if (code.length() > 1) {

			String newCode = code.substring(1);

			if (code.charAt(0) == '.') {
				fetchNode​(root.leftChild, newCode);
		
			} else if (code.charAt(0) == '-') {
				fetchNode​(root.rightChild, newCode);
			}
		}

		return letterSearched;
	}
	
	/**
	 * This operation is not supported in the MorseCodeTree
	 * @param data - data of node to be deleted
	 * @return reference to the current tree
	 * @throws UnsupportedOperationException
	 */
	public MorseCodeTree delete​(String data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException("This operation is not supported in the MorseCodeTree");
		
	}
	
	/**
	 * This operation is not supported in the MorseCodeTree
	 * @return reference to the current tree
	 * @throws UnsupportedOperationException
	 */
	public MorseCodeTree update() throws UnsupportedOperationException{
		throw new UnsupportedOperationException("This operation is not supported in the MorseCodeTree");
		
	}
	
	/**
	 * This method builds the MorseCodeTree by inserting the nodes of the tree level by level 
	 * into their proper locations based on the code. 
	 */
	public void buildTree() {
		root = new TreeNode<String>("");
		insert​(".", "e");
		insert​("-", "t");
		
		insert​("..", "i");
		insert​(".-", "a");
		insert​("-.", "n");
		insert​("--", "m");
		
		insert​("...", "s");
		insert​("..-", "u");
		insert​(".-.", "r");
		insert​(".--", "w");
		insert​("-..", "d");
		insert​("-.-", "k");
		insert​("--.", "g");
		insert​("---", "o");
		
		insert​("....", "h");
		insert​("...-", "v");
		insert​("..-.", "f");
		insert​(".-..", "l");
		insert​(".--.", "p");
		insert​(".---", "j");
		insert​("-...", "b");
		insert​("-..-", "x");
		insert​("-.-.", "c");
		insert​("-.--", "y");
		insert​("--..", "z");
		insert​("--.-", "q");
	}
	
	/**
	 * Returns an ArrayList of the items in the linked Tree in LNR (Inorder) Traversal order 
	 * Used for testing to make sure tree is built correctly
	 * @return an ArrayList of the items in the linked Tree
	 */
	public ArrayList<String> toArrayList(){
		ArrayList<String> treeArrayList = new ArrayList<String>();
		LNRoutputTraversal​(root, treeArrayList);
		return treeArrayList;
		
	}
	
	/**
	 * The recursive method to put the contents of the tree in an ArrayList in LNR (Inorder)
	 * @param root - the root of the tree for this particular recursive instance
	 * @param list - the ArrayList that will hold the contents of the tree in LNR order
	 */
	public void LNRoutputTraversal​(TreeNode<String> root, ArrayList<String> list) {
		if (root != null) {
			
			LNRoutputTraversal​(root.leftChild, list);
			list.add(root.getData());		
			LNRoutputTraversal​(root.rightChild, list);
		}
	}
}
